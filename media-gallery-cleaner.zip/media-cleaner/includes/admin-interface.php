<?php
class Media_Cleaner_Admin {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_media_cleaner_delete', array($this, 'ajax_delete_media'));
    }
    
    public function add_admin_menu() {
        add_media_page(
            'Media Cleaner',
            'Media Cleaner',
            'delete_others_posts',
            'media-cleaner',
            array($this, 'render_admin_page')
        );
    }
    
    public function enqueue_scripts($hook) {
        if ($hook !== 'media_page_media-cleaner') return;
        
        wp_enqueue_style(
            'media-cleaner-css',
            MEDIA_CLEANER_URL . 'assets/css/admin.css',
            array(),
            MEDIA_CLEANER_VERSION
        );
        
        wp_enqueue_script(
            'media-cleaner-js',
            MEDIA_CLEANER_URL . 'assets/js/admin.js',
            array('jquery', 'wp-util'),
            MEDIA_CLEANER_VERSION,
            true
        );
        
        wp_localize_script('media-cleaner-js', 'mediaCleaner', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('media_cleaner_nonce'),
            'confirmDelete' => esc_html__('Are you sure you want to delete the selected media files? This action cannot be undone.', 'media-cleaner'),
            'deleting' => esc_html__('Deleting...', 'media-cleaner'),
            'success' => esc_html__('Media files deleted successfully!', 'media-cleaner'),
            'error' => esc_html__('Error deleting media files.', 'media-cleaner'),
            'partial' => esc_html__('Some files could not be deleted.', 'media-cleaner'),
            'selectFiles' => esc_html__('Please select files to delete.', 'media-cleaner'),
            'fileDeleted' => esc_html__('file deleted', 'media-cleaner'),
            'filesDeleted' => esc_html__('files deleted', 'media-cleaner'),
            'fileNotDeleted' => esc_html__('file not deleted', 'media-cleaner'),
            'filesNotDeleted' => esc_html__('files not deleted', 'media-cleaner'),
            'allDeleted' => esc_html__('All unused media files have been deleted.', 'media-cleaner')
        ));
    }
    
    public function render_admin_page() {
        if (isset($_POST['scan_media'])) {
           if (
    !isset($_POST['_wpnonce']) || 
    !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'])), 'media_cleaner_scan')
) {
    wp_die(esc_html__('Security check failed', 'media-cleaner'));
}


            // Add media type to scan option
            $scan_type = isset($_POST['media_type']) ? sanitize_text_field(wp_unslash($_POST['media_type'])) : 'all';
            update_option('media_cleaner_last_scan_type', $scan_type);
            
            $unused_media = Media_Cleaner_Scanner::find_unused_media($scan_type);
            update_option('media_cleaner_unused', $unused_media);
            
        
add_settings_error(
    'media_cleaner_messages',
    'media_cleaner_message', // translators: %d is the number of unused media files found.
    sprintf(esc_html__('Scan complete. Found %d unused media files.', 'media-cleaner'), count($unused_media)),  
    'updated' 

);

        }
        
        settings_errors('media_cleaner_messages');
        $unused_media = get_option('media_cleaner_unused', array());
        $last_scan_type = get_option('media_cleaner_last_scan_type', 'all');
        
        // Add active filter variable
        $active_filter = isset($_GET['filter']) ? sanitize_text_field(wp_unslash($_GET['filter'])) : 'all';
        
        // Filter media by type if needed
        $filtered_media = array();
        $total_size = 0;
        
        foreach ($unused_media as $media_id) {
            $file = get_attached_file($media_id);
            if (!$file || !file_exists($file)) continue;
            
            $mime_type = get_post_mime_type($media_id);
            $file_type = explode('/', $mime_type)[0];
            
            // Apply filter
            if ($active_filter === 'all' || $file_type === $active_filter) {
                $filtered_media[] = $media_id;
                $total_size += filesize($file);
            }
        }
        ?>
        <div class="wrap">
            <h1 style="margin-block: 15px;">
                <span class="dashicons dashicons-format-image" style="vertical-align: middle; margin-right: 5px;"></span>
                <?php esc_html_e('Media Gallery Cleaner', 'media-cleaner'); ?>
            </h1>
            
            <div class="card__one">
                <h2 class="title"><?php esc_html_e('Scan Media Library', 'media-cleaner'); ?></h2>
                <p><?php esc_html_e('Scan your website for unused media files in the library.', 'media-cleaner'); ?></p>
                
                <form method="post">
                    <?php wp_nonce_field('media_cleaner_scan'); ?>
                    <div class="media-type-filters">
                        <label for="media_type"><?php esc_html_e('Scan specific media type:', 'media-cleaner'); ?></label>
                        <select name="media_type" id="media_type">
                            <option value="all" <?php selected($last_scan_type, 'all'); ?>><?php esc_html_e('All Media Types', 'media-cleaner'); ?></option>
                            <option value="image" <?php selected($last_scan_type, 'image'); ?>><?php esc_html_e('Images Only', 'media-cleaner'); ?></option>
                            <option value="video" <?php selected($last_scan_type, 'video'); ?>><?php esc_html_e('Videos Only', 'media-cleaner'); ?></option>
                            <option value="audio" <?php selected($last_scan_type, 'audio'); ?>><?php esc_html_e('Audio Only', 'media-cleaner'); ?></option>
                            <option value="application" <?php selected($last_scan_type, 'application'); ?>><?php esc_html_e('Documents Only', 'media-cleaner'); ?></option>
                        </select>
                    </div>
                    <?php submit_button(esc_html__('Scan for Unused Media', 'media-cleaner'), 'primary', 'scan_media'); ?>
                </form>
            </div>
            
            <?php if (!empty($unused_media)) : ?>
                <div class="card__one">
                    <h2 class="title"><?php esc_html_e('Unused Media Files', 'media-cleaner'); ?></h2>
                    <p>
                        <?php 
printf(
    // translators: 1: Number of unused files, 2: Formatted file size total.
    esc_html__('Found %1$d unused files totaling %2$s.', 'media-cleaner'),
    absint(count($filtered_media)), 
    esc_html(size_format($total_size))
); 
?>

                    </p>
                    
                    <div class="media-filter-tabs">
                        <a href="<?php echo esc_url(add_query_arg('filter', 'all')); ?>" class="<?php echo esc_attr($active_filter === 'all' ? 'active' : ''); ?>">
                            <?php esc_html_e('All', 'media-cleaner'); ?>
                        </a>
                        <a href="<?php echo esc_url(add_query_arg('filter', 'image')); ?>" class="<?php echo esc_attr($active_filter === 'image' ? 'active' : ''); ?>">
                            <?php esc_html_e('Images', 'media-cleaner'); ?>
                        </a>
                        <a href="<?php echo esc_url(add_query_arg('filter', 'video')); ?>" class="<?php echo esc_attr($active_filter === 'video' ? 'active' : ''); ?>">
                            <?php esc_html_e('Videos', 'media-cleaner'); ?>
                        </a>
                        <a href="<?php echo esc_url(add_query_arg('filter', 'audio')); ?>" class="<?php echo esc_attr($active_filter === 'audio' ? 'active' : ''); ?>">
                            <?php esc_html_e('Audio', 'media-cleaner'); ?>
                        </a>
                        <a href="<?php echo esc_url(add_query_arg('filter', 'application')); ?>" class="<?php echo esc_attr($active_filter === 'application' ? 'active' : ''); ?>">
                            <?php esc_html_e('Documents', 'media-cleaner'); ?>
                        </a>
                    </div>
                    
                    <div class="media-cleaner-actions">
                        <button id="select-all-media" class="button"><?php esc_html_e('Select All', 'media-cleaner'); ?></button>
                        <button id="deselect-all-media" class="button"><?php esc_html_e('Deselect All', 'media-cleaner'); ?></button>
                        <button id="delete-selected-media" class="button button-danger" 
                                data-confirm="<?php echo esc_attr__('Are you sure you want to delete the selected files?', 'media-cleaner'); ?>">
                            <?php esc_html_e('Delete Selected', 'media-cleaner'); ?>
                        </button>
                    </div>
                    
                    <div id="media-cleaner-progress" style="display:none;">
                        <div class="progress-bar">
                            <div class="progress"></div>
                        </div>
                        <p class="progress-text"><?php esc_html_e('Preparing to delete...', 'media-cleaner'); ?></p>
                    </div>
                    
                    <div id="media-cleaner-results"></div>
                    
                    <div class="media-grid">
                        <?php foreach ($filtered_media as $media_id) : 
                            $media = get_post($media_id);
                            if (!$media) continue;
                            
                            $thumb = wp_get_attachment_image($media_id, array(150, 150), true, array('class' => 'media-item-thumb'));
                            $filesize = size_format(filesize(get_attached_file($media_id)));
                            $mime_type = get_post_mime_type($media_id);
                            $file_type = explode('/', $mime_type)[0];
                            ?>
                            <div class="media-item" data-id="<?php echo esc_attr($media_id); ?>" data-type="<?php echo esc_attr($file_type); ?>">
                                <div class="media-item-select">
                                    <input type="checkbox" name="media_ids[]" value="<?php echo esc_attr($media_id); ?>">
                                </div>
                                <div class="media-item-thumbnail">
                                    <?php echo wp_kses_post($thumb); ?>
                                </div>
                                <div class="media-item-info">
                                    <h3><?php echo esc_html($media->post_title); ?></h3>
                                    <p><?php esc_html_e('ID:', 'media-cleaner'); ?> <?php echo esc_html($media_id); ?></p>
                                    <p><?php echo esc_html(get_the_date('', $media)); ?></p>
                                    <p><?php echo esc_html($filesize); ?></p>
                                    <p class="media-type-badge"><?php echo esc_html(ucfirst($file_type)); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    public function ajax_delete_media() {
        try {
            check_ajax_referer('media_cleaner_nonce', 'nonce');
            
            if (!current_user_can('delete_others_posts')) {
                throw new Exception(esc_html__('You do not have permission to delete media.', 'media-cleaner'));
            }

            if (empty($_POST['media_ids'])) {
                throw new Exception(esc_html__('No media selected.', 'media-cleaner'));
            }

            $media_ids = array_map('intval', $_POST['media_ids']);
            $results = [];
            $success_count = 0;
            $error_count = 0;

            foreach ($media_ids as $media_id) {
                $result = [
                    'id' => $media_id,
                    'status' => 'success',
                    'message' => ''
                ];

                try {
                    // Verify media exists
                    $media = get_post($media_id);
                    if (!$media || $media->post_type !== 'attachment') {
                        /* translators: %d: Media ID */
                        throw new Exception(sprintf(esc_html__('Invalid media ID: %d', 'media-cleaner'), $media_id));
                    }

                    // Get file path before deletion
                    $file_path = get_attached_file($media_id);
                    $file_exists_before = $file_path && file_exists($file_path);

                    // Delete the attachment
                    $deleted = wp_delete_attachment($media_id, true);
                    
                    if (!$deleted || is_wp_error($deleted)) {
                        /* translators: %d: Media ID */
                        throw new Exception(sprintf(esc_html__('Failed to delete media ID %d from database', 'media-cleaner'), $media_id));
                    }

                    // Verify deletion
                    $post_after = get_post($media_id);
                    if ($post_after && $post_after->post_type === 'attachment') {
                        /* translators: %d: Media ID */
                        throw new Exception(sprintf(esc_html__('Database record still exists for media ID %d', 'media-cleaner'), $media_id));
                    }

                    if ($file_exists_before && $file_path && file_exists($file_path)) {
                        /* translators: %d: Media ID */
                        $result['message'] = sprintf(esc_html__('Media ID %d database record deleted but file may still exist', 'media-cleaner'), $media_id);
                        $result['status'] = 'warning';
                    } else {
                        /* translators: %d: Media ID */
                        $result['message'] = sprintf(esc_html__('Media ID %d deleted successfully', 'media-cleaner'), $media_id);
                    }

                    $success_count++;
                    $results[] = $result;
                    
                } catch (Exception $e) {
                    $result['status'] = 'error';
                    $result['message'] = $e->getMessage();
                    $results[] = $result;
                    $error_count++;
                }
            }

            // Update the unused media list
            if ($success_count > 0) {
                $unused_media = get_option('media_cleaner_unused', []);
                $unused_media = array_diff($unused_media, $media_ids);
                update_option('media_cleaner_unused', $unused_media);
            }

            // Prepare response
            $response = [
                'success_count' => $success_count,
                'error_count' => $error_count,
                'results' => $results,
                'status' => $error_count === 0 ? 'complete' : ($success_count > 0 ? 'partial' : 'error')
            ];

            wp_send_json_success($response);

        } catch (Exception $e) {
            wp_send_json_error([
                'message' => $e->getMessage()
            ]);
        }
    }
}