<?php
add_action('wp_ajax_media_cleaner_delete', 'handle_media_cleaner_delete');

// function handle_media_cleaner_delete() {
//     try {
//         // Start error logging
//         error_log('Media Cleaner AJAX Start - Memory Usage: ' . memory_get_usage());
        
//         // Verify nonce
//         if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'media_cleaner_nonce')) {
//             throw new Exception('Invalid nonce');
//         }

//         // Check permissions
//         if (!current_user_can('delete_others_posts')) {
//             throw new Exception('Insufficient permissions');
//         }

//         // Validate media IDs
//         if (empty($_POST['media_ids'])) {
//             throw new Exception('No media IDs provided');
//         }

//         $media_ids = array_map('intval', $_POST['media_ids']);
//         error_log('Processing media IDs: ' . implode(',', $media_ids));

//         $results = [];
//         foreach ($media_ids as $media_id) {
//             try {
//                 if (Media_Cleaner_Scanner::is_media_used($media_id)) {
//                     throw new Exception("Media ID {$media_id} is in use");
//                 }

//                 $file_path = get_attached_file($media_id);
//                 if (!file_exists($file_path)) {
//                     throw new Exception("File not found for media ID {$media_id}");
//                 }

//                 if (!is_writable($file_path)) {
//                     throw new Exception("File not writable for media ID {$media_id}");
//                 }

//                 $result = wp_delete_attachment($media_id, true);
//                 if (!$result || is_wp_error($result)) {
//                     throw new Exception("Deletion failed for media ID {$media_id}");
//                 }

//                 $results[] = ['id' => $media_id, 'status' => 'success'];
//             } catch (Exception $e) {
//                 error_log('Error with media ID ' . $media_id . ': ' . $e->getMessage());
//                 $results[] = ['id' => $media_id, 'status' => 'error', 'message' => $e->getMessage()];
//             }
//         }

//         wp_send_json_success(['results' => $results]);
        
//     } catch (Exception $e) {
//         error_log('Media Cleaner Fatal Error: ' . $e->getMessage());
//         status_header(500);
//         wp_send_json_error(['message' => $e->getMessage()]);
//     }
// }