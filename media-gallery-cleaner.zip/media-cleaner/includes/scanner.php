<?php
class Media_Cleaner_Scanner {

public static function scan_for_used_media() {
    $used_media = [];

    $posts = get_posts([
        'post_type' => 'any',
        'post_status' => 'any',
        'numberposts' => -1,
        'fields' => 'ids',
    ]);

    foreach ($posts as $post_id) {
        $post = get_post($post_id);
        $content = $post->post_content;

        preg_match_all('/wp-image-(\d+)/', $content, $matches);
        if (!empty($matches[1])) {
            $used_media = array_merge($used_media, $matches[1]);
        }

        $used_media = array_merge($used_media, self::extract_media_ids_from_text($content));

        $thumbnail_id = get_post_thumbnail_id($post_id);
        if ($thumbnail_id) {
            $used_media[] = $thumbnail_id;
        }

        preg_match_all('/\[gallery.*ids="([^"]*)"/', $content, $gallery_matches);
        if (!empty($gallery_matches[1])) {
            $ids = array_filter(explode(',', $gallery_matches[1][0]));
            $used_media = array_merge($used_media, $ids);
        }

        $custom_fields = get_post_meta($post_id);
        foreach ($custom_fields as $field => $values) {
            foreach ($values as $value) {
                $used_media = array_merge($used_media, self::extract_ids_from_meta($value));
            }
        }
    }

    $used_media = array_merge($used_media, self::scan_widgets_for_media());
    $used_media = array_merge($used_media, self::scan_directory_for_media(get_template_directory()));

    if (class_exists('WooCommerce')) {
        $used_media = array_merge($used_media, self::scan_woocommerce_gallery());
    }

    if (class_exists('ACF')) {
        $used_media = array_merge($used_media, self::scan_acf_fields());
    }

    return array_unique(array_map('intval', $used_media));
}

private static function scan_woocommerce_gallery() {
    $media_ids = [];
    $products = get_posts([
        'post_type' => 'product',
        'numberposts' => -1,
    ]);

    foreach ($products as $product) {
        $gallery_ids = get_post_meta($product->ID, '_product_image_gallery', true);
        if ($gallery_ids) {
            $ids = array_filter(explode(',', $gallery_ids));
            $media_ids = array_merge($media_ids, $ids);
        }
    }

    return $media_ids;
}

private static function scan_acf_fields() {
    $media_ids = [];
    $field_groups = acf_get_field_groups();
    
    foreach ($field_groups as $field_group) {
        $fields = acf_get_fields($field_group);
        foreach ($fields as $field) {
            if (in_array($field['type'], ['image', 'gallery', 'file'])) {
               $values = get_posts([
    'post_type' => 'any',
    'meta_key' => $field['name'],  // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key

    'meta_compare' => 'EXISTS',
    'fields' => 'ids',
    'numberposts' => -1,
]);
                
                foreach ($values as $post_id) {
                    $value = get_field($field['name'], $post_id, false);
                    if (is_array($value)) {
                        $media_ids = array_merge($media_ids, $value);
                    } elseif (!empty($value)) {
                        $media_ids[] = $value;
                    }
                }
            }
        }
    }
    
    return $media_ids;
}

    private static function extract_ids_from_meta($value) {
        $media_ids = [];

        if (is_serialized($value)) {
            $value = maybe_unserialize($value);
        }

        if (is_array($value)) {
            array_walk_recursive($value, function ($item) use (&$media_ids) {
                if (is_numeric($item) && get_post($item)) {
                    $media_ids[] = $item;
                } elseif (is_string($item) && strpos($item, '/uploads/') !== false) {
                    $id = attachment_url_to_postid($item);
                    if ($id) $media_ids[] = $id;
                }
            });
        } else {
            if (is_numeric($value) && get_post($value)) {
                $media_ids[] = $value;
            } elseif (is_string($value) && strpos($value, '/uploads/') !== false) {
                $id = attachment_url_to_postid($value);
                if ($id) $media_ids[] = $id;
            }
        }

        return $media_ids;
    }

    private static function extract_media_ids_from_text($text) {
        $media_ids = [];
        preg_match_all('/https?:\/\/[^\'"\s]+\/uploads\/[^\'"\s]+/', $text, $matches);
        if (!empty($matches[0])) {
            foreach ($matches[0] as $url) {
                $id = attachment_url_to_postid($url);
                if ($id) $media_ids[] = $id;
            }
        }

        return $media_ids;
    }

    private static function scan_directory_for_media($directory) {
        $media_ids = [];
        $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($directory));

        foreach ($files as $file) {
            if ($file->isDir()) continue;
            $content = file_get_contents($file->getRealPath());
            preg_match_all('/wp-image-(\d+)/', $content, $matches);
            if (!empty($matches[1])) {
                $media_ids = array_merge($media_ids, $matches[1]);
            }
            $media_ids = array_merge($media_ids, self::extract_media_ids_from_text($content));
        }

        return $media_ids;
    }

    private static function scan_widgets_for_media() {
        $media_ids = [];
        $all_options = wp_load_alloptions();

        foreach ($all_options as $key => $value) {
            if (is_serialized($value)) {
                $value = maybe_unserialize($value);
            }

            if (is_array($value)) {
                array_walk_recursive($value, function ($item) use (&$media_ids) {
                    $media_ids = array_merge($media_ids, self::extract_ids_from_meta($item));
                });
            } elseif (is_string($value)) {
                $media_ids = array_merge($media_ids, self::extract_ids_from_meta($value));
            }
        }

        return $media_ids;
    }

    public static function find_unused_media($type = 'all') {
        $used_media = self::scan_for_used_media();
        $all_media = get_posts([
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'numberposts' => -1,
            'fields' => 'ids'
        ]);

        $unused_media = [];
        foreach ($all_media as $media_id) {
            if (in_array($media_id, $used_media)) continue;

            $mime_type = get_post_mime_type($media_id);
            $file_type = explode('/', $mime_type)[0];

            if ($type === 'all' || $file_type === $type) {
                if (!self::is_media_used($media_id)) {
                    $unused_media[] = $media_id;
                }
            }
        }

        return $unused_media;
    }

public static function is_media_used($media_id) {
    global $wpdb;

    $attachment_url = wp_get_attachment_url($media_id);
    $attachment_path = get_attached_file($media_id);

    if (!$attachment_url || !$attachment_path) {
        return false;
    }

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $content_check = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $wpdb->posts 
        WHERE post_content LIKE %s 
        OR post_content LIKE %s 
        OR post_content LIKE %s",
        '%' . $wpdb->esc_like('wp-image-' . $media_id) . '%',
        '%' . $wpdb->esc_like($attachment_url) . '%',
        '%' . $wpdb->esc_like(basename($attachment_path)) . '%'
    ));

    if ($content_check > 0) return true;

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $meta_check = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $wpdb->postmeta 
        WHERE meta_value = %d 
        OR meta_value LIKE %s 
        OR meta_value LIKE %s",
        $media_id,
        '%' . $wpdb->esc_like($attachment_url) . '%',
        '%' . $wpdb->esc_like('"' . $media_id . '"') . '%'
    ));

    if ($meta_check > 0) return true;

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $option_check = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $wpdb->options 
        WHERE option_value LIKE %s 
        OR option_value LIKE %s",
        '%' . $wpdb->esc_like($attachment_url) . '%',
        '%' . $wpdb->esc_like('"' . $media_id . '"') . '%'
    ));

    if ($option_check > 0) return true;

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
   $widget_check = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM $wpdb->options 
     WHERE option_name LIKE %s 
     AND option_value LIKE %s",
    $wpdb->esc_like('widget_') . '%',
    '%' . $wpdb->esc_like($attachment_url) . '%'
));


    if ($widget_check > 0) return true;

    $theme_mods = get_theme_mods();
    if (is_array($theme_mods)) {
        array_walk_recursive($theme_mods, function($value) use (&$used, $media_id, $attachment_url) {
            if ((is_string($value) && (strpos($value, $attachment_url) !== false || strpos($value, 'wp-image-' . $media_id) !== false)) ||
                (is_numeric($value) && $value == $media_id)) {
                $used = true;
            }
        });
    }

    return isset($used) ? $used : false;
}


    public static function get_duplicate_media() {
        $hashes = [];
        $duplicates = [];

        $attachments = get_posts([
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'numberposts' => -1,
        ]);

        foreach ($attachments as $attachment) {
            $file = get_attached_file($attachment->ID);
            if ($file && file_exists($file)) {
                $hash = md5_file($file);
                if (isset($hashes[$hash])) {
                    $duplicates[] = $attachment->ID;
                } else {
                    $hashes[$hash] = $attachment->ID;
                }
            }
        }

        return $duplicates;
    }
}
