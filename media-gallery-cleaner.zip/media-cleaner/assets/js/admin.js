jQuery(document).ready(function($) {
    const MediaCleaner = {
        init: function() {
            this.bindEvents();
        },
        
        bindEvents: function() {
            $('#select-all-media').on('click', this.selectAllMedia);
            $('#deselect-all-media').on('click', this.deselectAllMedia);
            $('#delete-selected-media').on('click', this.deleteSelectedMedia);
            $('#reset-scan-cache').on('click', this.resetScanCache);
        },
        
        selectAllMedia: function(e) {
            e.preventDefault();
            $('.media-item input[type="checkbox"]').prop('checked', true).trigger('change');
        },
        
        deselectAllMedia: function(e) {
            e.preventDefault();
            $('.media-item input[type="checkbox"]').prop('checked', false).trigger('change');
        },
        
        deleteSelectedMedia: function(e) {
            e.preventDefault();
            
            const selected = $('.media-item input[type="checkbox"]:checked').map(function() {
                return parseInt($(this).val());
            }).get();
            
            if (selected.length === 0) {
                alert(mediaCleaner.selectFiles);
                return;
            }
            
            if (!confirm($(this).data('confirm'))) {
                return;
            }
            
            MediaCleaner.startDeletion(selected);
        },
        
        resetScanCache: function(e) {
            e.preventDefault();
            
            if (confirm(mediaCleaner.confirmReset)) {
                wp.ajax.post('media_cleaner_reset_cache', {
                    nonce: mediaCleaner.nonce
                }).done(function(response) {
                    alert(response.data.message);
                }).fail(function(response) {
                    alert(response.data.message || mediaCleaner.error);
                });
            }
        },
        
        startDeletion: function(mediaIds) {
            $('#media-cleaner-progress').show();
            $('.progress-text').text(mediaCleaner.deleting);
            $('.progress').css('width', '0%');
            $('#delete-selected-media').prop('disabled', true);
            
            const batchSize = 5;
            const total = mediaIds.length;
            let processed = 0;
            let successCount = 0;
            let errorCount = 0;
            let allResults = [];
            
            const processBatch = (startIndex) => {
                const endIndex = Math.min(startIndex + batchSize, total);
                const batch = mediaIds.slice(startIndex, endIndex);
                
                $.ajax({
                    url: mediaCleaner.ajax_url,
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'media_cleaner_delete',
                        media_ids: batch,
                        nonce: mediaCleaner.nonce
                    },
                    success: (response) => {
                        processed += batch.length;
                        MediaCleaner.updateProgress(processed, total);
                        
                        if (response.data) {
                            successCount += response.data.success_count || 0;
                            errorCount += response.data.error_count || 0;
                            
                            if (response.data.results) {
                                allResults = allResults.concat(response.data.results);
                            }
                        }
                        
                        if (endIndex < total) {
                            processBatch(endIndex);
                        } else {
                            MediaCleaner.deletionComplete(successCount, errorCount, allResults);
                        }
                    },
                    error: () => {
                        processed += batch.length;
                        errorCount += batch.length;
                        MediaCleaner.updateProgress(processed, total);
                        
                        if (endIndex < total) {
                            processBatch(endIndex);
                        } else {
                            MediaCleaner.deletionComplete(successCount, errorCount, allResults);
                        }
                    }
                });
            };
            
            processBatch(0);
        },
        
        updateProgress: function(processed, total) {
            const progress = Math.round((processed / total) * 100);
            $('.progress').css('width', progress + '%');
            $('.progress-text').text(
                `${mediaCleaner.deleting} ${processed}/${total}`
            );
        },
        
        deletionComplete: function(successCount, errorCount, allResults) {
            let resultClass = 'success';
            let message = '';
            
            if (errorCount === 0) {
                message = `${successCount} ${successCount === 1 ? mediaCleaner.fileDeleted : mediaCleaner.filesDeleted}`;
            } else if (successCount > 0) {
                resultClass = 'warning';
                message = `${successCount} ${successCount === 1 ? mediaCleaner.fileDeleted : mediaCleaner.filesDeleted}`;
                if (errorCount > 0) {
                    message += `, ${errorCount} ${errorCount === 1 ? mediaCleaner.fileNotDeleted : mediaCleaner.filesNotDeleted}`;
                }
            } else {
                resultClass = 'error';
                message = mediaCleaner.error;
            }
            
            const resultHtml = `
                <div class="notice notice-${resultClass}">
                    <p>${message}</p>
                    ${errorCount > 0 ? `<p><small>${mediaCleaner.checkLogs}</small></p>` : ''}
                </div>
            `;
            
            $('#media-cleaner-results').html(resultHtml);
            
            allResults.forEach(result => {
                if (result.status === 'success') {
                    $(`.media-item[data-id="${result.id}"]`).fadeOut(300, function() {
                        $(this).remove();
                        MediaCleaner.checkEmptyState();
                    });
                }
            });
            
            $('#delete-selected-media').prop('disabled', false);
            MediaCleaner.checkEmptyState();
        },
        
        checkEmptyState: function() {
            const remaining = $('.media-item').length;
            if (remaining === 0) {
                $('.media-grid').html(`<p>${mediaCleaner.allDeleted}</p>`);
                $('#media-cleaner-progress').hide();
            }
        }
    };
    
    MediaCleaner.init();
});