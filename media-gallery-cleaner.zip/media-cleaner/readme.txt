=== Media Gallery Cleaner ===
Contributors: umii010
Tags: media cleaner, media optimization, unused media, image cleanup
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Scans your website and identifies unused media files for cleanup.

== Description ==

Media Gallery Cleaner scans your WordPress media library and database to identify unused images and other media files. It helps you clean up your site and free up server space.

== Installation ==

1. Upload the plugin to your `/wp-content/plugins/` directory.
2. Activate the plugin through the ‘Plugins’ menu in WordPress.
3. Go to Media > Media Cleaner to start scanning.

== Changelog ==

= 1.0.0 =
* Initial release.
