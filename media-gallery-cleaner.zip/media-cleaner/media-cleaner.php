<?php
/*
Plugin Name: Media Gallery Cleaner
Plugin URI: https://www.github.com/Umii010/media-gallery-cleaner
Description: Scans your website and identifies unused media files for cleanup.
Version: 1.0.0
Author: Muhammad Umer Shahzad
Author URI: https://devvault.io
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: media-cleaner
*/

defined('ABSPATH') or die('Direct access not allowed');

// Define constants
define('MEDIA_CLEANER_VERSION', '1.0');
define('MEDIA_CLEANER_PATH', plugin_dir_path(__FILE__));
define('MEDIA_CLEANER_URL', plugin_dir_url(__FILE__));

// Include necessary files
require_once MEDIA_CLEANER_PATH . 'includes/scanner.php';
require_once MEDIA_CLEANER_PATH . 'includes/admin-interface.php';

// Initialize the plugin
if (is_admin()) {
    new Media_Cleaner_Admin();

}