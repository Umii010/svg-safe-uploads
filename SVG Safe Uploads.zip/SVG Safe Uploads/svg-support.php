<?php
/**
 * Plugin Name: SVG Safe Uploads
 * Plugin URI: https://github.com/Umii010/svg-safe-uploads
 * Description: Enables secure SVG uploads with sanitization and a stylish dashboard.
 * Version: 1.2
 * Author: Muhammad Umer Shahzad
 * Author URI: https://github.com/Umii010
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
* Text Domain: SVG Safe Uploads

 */

if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

require_once plugin_dir_path(__FILE__) . 'admin-settings.php';

// Load Composer Autoload (if exists)
$autoload_path = plugin_dir_path(__FILE__) . 'vendor/autoload.php';
if (file_exists($autoload_path)) {
    require_once $autoload_path;
}

// Enqueue Styles
function svg_support_admin_assets() {
    wp_enqueue_style('svg-support-admin', plugin_dir_url(__FILE__) . 'css/admin-style.css', array(), '1.2');
}
add_action('admin_enqueue_scripts', 'svg_support_admin_assets');

// Add Admin Menu
function svg_support_admin_menu() {
    add_menu_page(
        'SVG Support', 
        'SVG Support', 
        'manage_options', 
        'svg-support-dashboard', 
        'svg_support_dashboard_page', // FIXED: Correct function name
        'dashicons-format-image', 
        25
    );
}
add_action('admin_menu', 'svg_support_admin_menu');

// Activation Hook
function svg_support_activate() {
    add_option('svg_support_enabled', 'yes');
    add_option('svg_support_restrict_admins', 'no');
}
register_activation_hook(__FILE__, 'svg_support_activate');

// Deactivation Hook
function svg_support_deactivate() {
    delete_option('svg_support_enabled');
    delete_option('svg_support_restrict_admins');
}
register_deactivation_hook(__FILE__, 'svg_support_deactivate');

// Allow SVG Uploads Based on Settings
function svg_support_mime_types($mimes) {
    if (get_option('svg_support_enabled', 'yes') === 'yes') {
        if (get_option('svg_support_restrict_admins', 'no') === 'yes' && !current_user_can('manage_options')) {
            return $mimes; // Only allow admins if restriction is enabled
        }
        $mimes['svg'] = 'image/svg+xml';
    }
    return $mimes;
}
add_filter('upload_mimes', 'svg_support_mime_types');

// Secure SVG Uploads
function svg_support_sanitize_svg($file) {
    if ($file['type'] === 'image/svg+xml') {
        $autoload_path = plugin_dir_path(__FILE__) . 'vendor/autoload.php';
        if (file_exists($autoload_path)) {
            require_once $autoload_path;
            $sanitizer = new \enshrined\svgSanitize\Sanitizer();
            $clean_svg = $sanitizer->sanitize(file_get_contents($file['tmp_name']));
            file_put_contents($file['tmp_name'], $clean_svg);
        }
    }
    return $file;
}
add_filter('wp_handle_upload_prefilter', 'svg_support_sanitize_svg');

// Validate SVG Uploads
function svg_support_validate_svg_upload($filetype, $file, $filename, $mimes) {
    if ($filetype['ext'] === 'svg' && $filetype['type'] === 'image/svg+xml') {
        $filetype['ext'] = 'svg';
        $filetype['type'] = 'image/svg+xml';
    }
    return $filetype;
}
add_filter('wp_check_filetype_and_ext', 'svg_support_validate_svg_upload', 10, 4);

