=== SVG Safe Uploads ===
Contributors: Umii010
Donate link: https://github.com/Umii010
Tags: svg, uploads, security, media
Requires at least: 5.0
Tested up to: 6.7
Stable tag: 1.2
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Securely upload SVG files in WordPress with built-in sanitization and admin settings.

== Description ==

A lightweight WordPress plugin to safely upload and sanitize SVG files with admin controls. Enables secure SVG uploads in WordPress with sanitization and admin controls.

== Installation ==

1. Download and activate the plugin.
2. Go to **Settings → SVG Support** to configure.

== Frequently Asked Questions ==

= Is it safe to upload SVG files? =

Yes, SVG sanitization is included.

= What versions of WordPress does this plugin support? =

This plugin supports WordPress versions 5.0 and up.

== Screenshots ==

1. Screenshot of the plugin settings page. Corresponds to screenshot-1.png.
2. Another screenshot of the SVG preview. Corresponds to screenshot-2.png.

== Changelog ==

= 1.2 =
* Improved sanitization and security for SVG uploads.
* Added better admin controls for SVG file management.

= 1.1 =
* Improved UI and added uninstall cleanup.

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.2 =
Improved sanitization and security for SVG uploads. Please update immediately to ensure proper handling of SVG files.

= 1.1 =
Improved UI and fixed some issues with SVG uploads.

== A brief Markdown Example ==

Markdown is what the parser uses to process much of the readme file.

[markdown syntax]: https://daringfireball.net/projects/markdown/syntax

Ordered list:

1. Install plugin
2. Configure settings
3. Upload SVG files

Unordered list:

* Secure upload of SVG files
* Sanitization for better security
* Admin control settings

Links require brackets and parenthesis:

Here's a link to [WordPress](https://wordpress.org/ "Your favorite software") and one to [Markdown's Syntax Documentation][markdown syntax]. Link titles are optional, naturally.

Blockquotes are email style:

> Asterisks for *emphasis*. Double it up for **strong**.

And Backticks for code:

`<?php code(); ?>`
