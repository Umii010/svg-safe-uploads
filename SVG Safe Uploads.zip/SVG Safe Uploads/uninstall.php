<?php
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Delete stored options
delete_option('svg_support_enabled');
delete_option('svg_support_restrict_admins');
