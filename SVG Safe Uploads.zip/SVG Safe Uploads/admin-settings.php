<?php
if (!defined('ABSPATH')) {
    exit; // Prevent direct access
}

// Register Settings
function svg_support_register_settings() {
    register_setting('svg_support_options_group', 'svg_support_enabled', 'svg_support_sanitize_checkbox');
    register_setting('svg_support_options_group', 'svg_support_restrict_admins', 'svg_support_sanitize_checkbox');
}
add_action('admin_init', 'svg_support_register_settings');

// Sanitize Checkbox Inputs
function svg_support_sanitize_checkbox($input) {
    return isset($input) ? 'yes' : 'no';
}

// Display Settings Page
function svg_support_dashboard_page() {
    $enabled = get_option('svg_support_enabled', 'yes');
    $restrict_to_admins = get_option('svg_support_restrict_admins', 'no');
    ?>
    <div class="wrap svg-dashboard">
        <h1>🎨 SVG Support Dashboard</h1>
        
        <div class="svg-dashboard-grid">
            <!-- Left Section -->
            <div class="svg-box svg-settings">
                <h2>🔧 Plugin Settings</h2>
                <form method="post" action="options.php">
                    <?php
                    settings_fields('svg_support_options_group');
                    do_settings_sections('svg-support');
                    ?>
                    <div class="svg-setting-item">
                        <label class="svg-toggle">
                            <input type="checkbox" name="svg_support_enabled" value="yes" <?php checked($enabled, 'yes'); ?>>
                            <span class="svg-slider"></span>
                            <span class="svg-label">Enable SVG Uploads</span>
                        </label>
                    </div>
                    <div class="svg-setting-item">
                        <label class="svg-toggle">
                            <input type="checkbox" name="svg_support_restrict_admins" value="yes" <?php checked($restrict_to_admins, 'yes'); ?>>
                            <span class="svg-slider"></span>
                            <span class="svg-label">Restrict SVG Uploads to Admins Only</span>
                        </label>
                    </div>
                    <div class="svg-setting-item">
                        <?php submit_button('Save Settings', 'primary', 'submit', false); ?>
                    </div>
                </form>

                <h2>📢 Instructions</h2>
                <div class="svg-instructions">
                    <p>✅ To upload SVG files, go to <strong>Media → Add New</strong> and upload your SVG file.</p>
                    <p>✅ Enable or disable SVG support anytime using the above settings.</p>
                </div>
            </div>

            <!-- Right Section (Info Box) -->
            <div class="svg-box svg-info">
                <h2>ℹ️ Plugin Info</h2>
                <div class="svg-info-content">
                    <p><strong>Plugin Name:</strong> SVG Support</p>
                    <p><strong>Version:</strong> 1.1</p>
                    <p><strong>Author:</strong> Muhammad Umer Shahzad</p>
                    <p><strong>Website:</strong> <a href="https://github.com/Umii010" target="_blank" class="svg-btn">GitHub</a></p>
                </div>
            </div>
        </div>
        
        <!-- SVG Preview Feature -->
        <div class="svg-preview">
            <h2>🔍 SVG Preview</h2>
            <p>Recent SVG Uploads:</p>
            <div class="svg-preview-grid">
                <?php
                $args = array(
                    'post_type' => 'attachment',
                    'post_mime_type' => 'image/svg+xml',
                    'posts_per_page' => 3,
                );
                $svgs = get_posts($args);
                if ($svgs) {
                    foreach ($svgs as $svg) {
                        echo '<div class="svg-preview-item"><img src="' . esc_url(wp_get_attachment_url($svg->ID)) . '" alt="' . esc_attr(get_the_title($svg->ID)) . '"></div>';
                    }
                } else {
                    echo "<p>No SVGs uploaded yet.</p>";
                }
                ?>
            </div>
        </div>
    </div>
    <!-- Rating Section -->
<div class="svg-box svg-rating">
    <h2>⭐ Rate This Plugin</h2>
    <p>If you find this plugin helpful, please consider leaving a rating.</p>
    <a href="https://wordpress.org/plugins/svg-support/#reviews" target="_blank" class="svg-btn">Leave a Review</a>
</div>

    <?php
}
